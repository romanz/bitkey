#!/bin/bash
arecord -f S16_LE -c 1 -r 32000 $*
